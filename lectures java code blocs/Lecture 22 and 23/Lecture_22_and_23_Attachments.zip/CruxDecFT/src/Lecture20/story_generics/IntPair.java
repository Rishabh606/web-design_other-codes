package Lecture20.story_generics;

// Problem - could not reuse data types
public class IntPair {
	int one;
	int two;
}
