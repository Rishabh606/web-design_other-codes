package Lecture12A.InPolStory;

public class C extends P {
	public int d21 = 21;
	public int d = 20;
	
	public void Fun(){
		super.Fun();
		System.out.println("C's Fun");
	}
	
	public void Fun2(){
		System.out.println("C's Fun2");
	}
	
	public static void SFun(){
		System.out.println("C's static Fun");
	}
}
