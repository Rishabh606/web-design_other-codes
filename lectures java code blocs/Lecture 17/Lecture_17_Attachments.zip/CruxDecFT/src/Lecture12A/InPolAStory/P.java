package Lecture12A.InPolAStory;

public abstract class P {
	public int d11 = 11;
	public int d = 10;
	
	public abstract void Fun();
	
	public void Fun1(){
		System.out.println("P's Fun1");
	}
}
