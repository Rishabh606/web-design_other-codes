package Lecture12.story1;

public class Person {
	int age = 100;
	String name;
	static int MoneyWLimit;

	public Person(int age, String name){
		this.age = age;
		this.name = name;
	}
	
	public Person(){
		
	}
}
