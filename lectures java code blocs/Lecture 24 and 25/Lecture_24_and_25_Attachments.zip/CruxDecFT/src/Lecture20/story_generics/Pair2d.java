package Lecture20.story_generics;

public class Pair2d<T1, T2> {
	T1 one;
	T2 two;
}
