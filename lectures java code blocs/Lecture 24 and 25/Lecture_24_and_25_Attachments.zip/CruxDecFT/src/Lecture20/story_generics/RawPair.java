package Lecture20.story_generics;

// SOLUTION 1
// Reusability solved, but gets are inconvenient and dangerous
public class RawPair {
	Object one;
	Object two;
}
