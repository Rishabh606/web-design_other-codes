package Lecture12A.InPolStory;

//public final class P {
public class P {
	public int d11 = 11;
	public int d = 10;
	
//	public final void Fun(){
	public void Fun(){
		System.out.println("P's Fun");
	}
	
	public void Fun1(){
		System.out.println("P's Fun1");
	}
	
	public static void SFun(){
		System.out.println("P's static Fun");
	}
}
