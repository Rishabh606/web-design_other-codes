
public class SimpleInterest {

	public static void main(String[] args) {
		// TODO Auto-generated method st
		int p = 100;
		int r = 10;
		int t = 2;

		int si = (p * r * t) / 100;
		System.out.println("Simple Interest " + si);
	}

}
