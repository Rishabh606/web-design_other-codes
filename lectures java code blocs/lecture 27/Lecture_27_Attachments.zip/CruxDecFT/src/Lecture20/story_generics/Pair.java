package Lecture20.story_generics;

// Superior vis-a-vis RawPair
// Reusability - solved, set - solved, get - solved
public class Pair<T> {
	T one;
	T two;
}
