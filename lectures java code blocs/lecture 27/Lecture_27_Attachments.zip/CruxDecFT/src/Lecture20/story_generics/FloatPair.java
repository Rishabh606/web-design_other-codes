package Lecture20.story_generics;

// Problem - could not reuse data types
public class FloatPair {
	float one;
	float two;
}
