package Lecture22;

public class Client {

	public static void main(String[] args) {
//		TTT obj = new TTT();
		MTDemo obj = new MTDemo();
	}

}
