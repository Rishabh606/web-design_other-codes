package Lecture12A.InPolAStory;

public class Client {

	public static void main(String[] args) {
		
	}

}
