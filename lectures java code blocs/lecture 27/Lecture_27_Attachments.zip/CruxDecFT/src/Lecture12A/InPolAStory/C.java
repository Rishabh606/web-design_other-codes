package Lecture12A.InPolAStory;

// Either provide the fn body or becoome abstract yourself
//public abstract class C extends P {
public class C extends P {
	public int d21 = 21;
	public int d = 20;
	
	@Override
	public void Fun(){
		System.out.println("C's Fun");
	}
	
	public void Fun2(){
		System.out.println("C's Fun2");
	}
}
