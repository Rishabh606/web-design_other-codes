package Lecture22.story2;

public class StudentClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
