package Lecture22.story1;

public class Person {
	int age;
	String name;
	
	Person(int age, String name){
		this.age = age;
		this.name = name;
	}
	
	Person(){
		
	}
}
