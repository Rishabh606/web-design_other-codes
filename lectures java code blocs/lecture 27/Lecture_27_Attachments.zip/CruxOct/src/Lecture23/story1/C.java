package Lecture23.story1;

public class C extends P {
	int d2 = 21;
	int d = 22;
	
	void Fun2(){
		System.out.println("C's Fun2.");
	}
	
	void Fun(){
		System.out.println("C's Fun");
	}
}
