package Lecture23.story1;

public class P {
	int d1 = 11;
	int d = 12;
	
	void Fun1(){
		System.out.println("P's Fun1.");
	}
	
	void Fun(){
		System.out.println("P's Fun");
	}
}
