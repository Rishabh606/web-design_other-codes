clc
clear all
x=(-100:0.01:100)'
unitstep= t>=0
plot(x,unistep)