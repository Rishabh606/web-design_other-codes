clc 
clear all
close all
x=(-2:.001:2);
y=exp(-3*abs(x));
plot(x,y)