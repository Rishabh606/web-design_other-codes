clc
clear all
close all
x=(0:.01:6*pi);
y=sin(sqrt(2)*x)+sin(2*x);
plot(x,y)