clc
clear all
close all
x= -100:1:100;
impulse = x==0;
plot(x,impulse)