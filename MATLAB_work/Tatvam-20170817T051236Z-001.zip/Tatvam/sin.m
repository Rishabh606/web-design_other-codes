clc
clear all
close all
x=(0:.01:20*pi);
y=sin(x)./x;
plot(x,y)